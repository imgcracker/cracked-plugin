<?php
$watermark_caching = "checked";
$watermark_type = "dw";
$watermark_position = "center-center";
$watermark_r_text = "www.mywebsite.com";
$r_font_size_factor = "55";
$watermark_text = "WATERMARKED";
$font_size_factor = "90";
$pure_watermark_stamp_image = "https://galaxyfunk.com/wp-content/singles/wccp-pro/images/testing-logo.png";
$margin_left_factor = "98";
$margin_top_factor = "98";
$watermark_color = "#000000";
$watermark_r_color = "#efefef";
$watermark_transparency = "65";
$watermark_rotation = "40";
$watermark_imagefilter = "None";
$watermark_signature = "This image is protected";
$home_path = "/var/www/galaxyfunk.com/htdocs/";
$upload_dir = "/var/www/galaxyfunk.com/htdocs/wp-content/uploads";
$baseurl = "https://galaxyfunk.com/wp-content/uploads";
?>