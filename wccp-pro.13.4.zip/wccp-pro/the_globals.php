<?php
//Get The Plugins URL as https://www.yrsite.com/dir/subdir
	$pluginsurl = plugins_url( '', __FILE__ );
?>