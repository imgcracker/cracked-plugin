<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p><br>Thank you so much for using Content Views Pro. You are using
	<code>CVPro <?php echo esc_html( PT_CV_Functions::plugin_info( PT_CV_FILE_PRO, 'Version' ) ); ?></code>,
	<code>CV <?php echo esc_html( PT_CV_Functions::plugin_info( PT_CV_FILE, 'Version' ) ); ?></code>
</p>