<?php
/**
 * Layout Name: One and others
 *
 * @package   PT_Content_Views
 * @author    PT Guy <http://www.contentviewspro.com/>
 * @license   GPL-2.0+
 * @link      http://www.contentviewspro.com/
 * @copyright 2015 PT Guy
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

echo implode( "\n", $fields_html );
