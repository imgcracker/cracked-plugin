<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

//$wbgSingleStyles = [];
foreach ( $wbgSingleStyles as $option_name => $option_value ) {
     if ( isset( $wbgSingleStyles[$option_name] ) ) {
         ${"" . $option_name} = $option_value;
     }
}
?>
<form name="wbg_single_style_form" role="form" class="form-horizontal" method="post" action="" id="wbg-single-style-form">
    <table class="wbg-single-style-settings-table">
        <!-- Master Container -->
        <tr>
            <th scope="row" colspan="4" style="text-align:left;">
                <hr><span><?php _e('Master Container', WBG_TXT_DOMAIN); ?></span><hr>
            </th>
        </tr>
        <tr>
            <th scope="row">
                <label><?php _e('Width', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input type="number" min="40" max="2000" step="1" name="wbg_single_container_width" value="<?php esc_attr_e( $wbg_single_container_width ); ?>">
                    <select name="wbg_single_container_width_type" class="medium-text">
                        <option value="px" <?php echo ( 'px' === $wbg_single_container_width_type ) ? 'selected' : ''; ?> ><?php echo 'px'; ?></option>
                        <option value="%" <?php echo ( '%' === $wbg_single_container_width_type ) ? 'selected' : ''; ?> ><?php echo '%'; ?></option>
                    </select>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label><?php _e('Margin Top', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <input type="number" class="medium-text" min="0" max="200" name="wbg_single_container_margin_top" id="wbg_single_container_margin_top" value="<?php esc_attr_e( $wbg_single_container_margin_top ); ?>">
                <code>px</code>
            </td>
            <th scope="row">
                <label><?php _e('Margin Bottom', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <input type="number" class="medium-text" min="0" max="200" name="wbg_single_container_margin_bottom" id="wbg_single_container_margin_bottom" value="<?php esc_attr_e( $wbg_single_container_margin_bottom ); ?>">
                <code>px</code>
            </td>
        </tr>
        <tr>
            <th scope="row" colspan="4" style="text-align:left;">
                <hr><span><?php _e('Title', WBG_TXT_DOMAIN); ?></span><hr>
            </th>
        </tr>
        <tr>
            <th scope="row">
                <label><?php _e('Font Color', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input class="wbg-wp-color" type="text" name="wbg_single_title_font_color" id="wbg_single_title_font_color" value="<?php esc_attr_e( $wbg_single_title_font_color ); ?>">
                    <div id="colorpicker"></div>
                    <?php
                }
                ?>
            </td>
            <th scope="row">
                <label><?php _e('Font Size', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input type="number" class="small-text" min="11" max="50" name="wbg_single_title_font_size" id="wbg_single_title_font_size" value="<?php esc_attr_e( $wbg_single_title_font_size ); ?>">
                    <code>px</code>
                    <?php
                }
                ?>
            </td>
        </tr>
        <!-- Sub Title -->
        <tr>
            <th scope="row" colspan="4" style="text-align:left;">
                <hr><span><?php _e('Sub Title', WBG_TXT_DOMAIN); ?></span><hr>
            </th>
        </tr>
        <tr>
            <th scope="row">
                <label><?php _e('Font Color', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input class="wbg-wp-color" type="text" name="wbg_single_subtitle_font_color" id="wbg_single_subtitle_font_color" value="<?php esc_attr_e( $wbg_single_subtitle_font_color ); ?>">
                    <div id="colorpicker"></div>
                    <?php
                }
                ?>
            </td>
            <th scope="row">
                <label><?php _e('Font Size', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input type="number" class="small-text" min="11" max="50" name="wbg_single_subtitle_font_size" id="wbg_single_subtitle_font_size" value="<?php esc_attr_e( $wbg_single_subtitle_font_size ); ?>">
                    <code>px</code>
                    <?php
                }
                ?>
            </td>
        </tr>
        <!-- Information Label -->
        <tr>
            <th scope="row" colspan="4" style="text-align:left;">
                <hr><span><?php _e('Information Label', WBG_TXT_DOMAIN); ?></span><hr>
            </th>
        </tr>
        <tr>
            <th scope="row">
                <label><?php _e('Font Color', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input class="wbg-wp-color" type="text" name="wbg_single_label_font_color" id="wbg_single_label_font_color" value="<?php esc_attr_e( $wbg_single_label_font_color ); ?>">
                    <div id="colorpicker"></div>
                    <?php
                }
                ?>
            </td>
            <th scope="row">
                <label><?php _e('Font Size', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input type="number" class="small-text" min="11" max="50" name="wbg_single_label_font_size" id="wbg_single_label_font_size" value="<?php esc_attr_e( $wbg_single_label_font_size ); ?>">
                    <code>px</code>
                    <?php
                }
                ?>
            </td>
        </tr>
        <!-- Information Text -->
        <tr>
            <th scope="row" colspan="4" style="text-align:left;">
                <hr><span><?php _e('Information Text', WBG_TXT_DOMAIN); ?></span><hr>
            </th>
        </tr>
        <tr>
            <th scope="row">
                <label><?php _e('Font Color', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input class="wbg-wp-color" type="text" name="wbg_single_info_font_color" id="wbg_single_info_font_color" value="<?php esc_attr_e( $wbg_single_info_font_color ); ?>">
                    <div id="colorpicker"></div>
                    <?php
                }
                ?>
            </td>
            <th scope="row">
                <label><?php _e('Font Size', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input type="number" class="small-text" min="11" max="50" name="wbg_single_info_font_size" id="wbg_single_info_font_size" value="<?php esc_attr_e( $wbg_single_info_font_size ); ?>">
                    <code>px</code>
                    <?php
                }
                ?>
            </td>
        </tr>
        <!-- Modal Popup -->
        <tr>
            <th scope="row" colspan="4" style="text-align:left;">
                <hr><span><?php _e('Modal Popup', WBG_TXT_DOMAIN); ?></span><hr>
            </th>
        </tr>
        <tr>
            <th scope="row">
                <label><?php _e('Height', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input type="number" class="small-text" min="300" max="1000" name="wbg_single_modal_height" id="wbg_single_modal_height" value="<?php esc_attr_e( $wbg_single_modal_height ); ?>">
                    <code>px</code>
                    <?php
                }
                ?>
            </td>
            <th scope="row">
                <label><?php _e('Width', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input type="number" class="small-text" min="300" max="1200" name="wbg_single_modal_width" id="wbg_single_modal_width" value="<?php esc_attr_e( $wbg_single_modal_width ); ?>">
                    <code>px</code>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label><?php _e('Background Color', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input class="wbg-wp-color" type="text" name="wbg_single_modal_bg_color" id="wbg_single_modal_bg_color" value="<?php esc_attr_e( $wbg_single_modal_bg_color ); ?>">
                    <div id="colorpicker"></div>
                    <?php
                }
                ?>
            </td>
            <th scope="row">
                <label><?php _e('Border Color', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input class="wbg-wp-color" type="text" name="wbg_single_modal_border_color" id="wbg_single_modal_border_color" value="<?php esc_attr_e( $wbg_single_modal_border_color ); ?>">
                    <div id="colorpicker"></div>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label><?php _e('Border Width', WBG_TXT_DOMAIN); ?></label>
            </th>
            <td>
                <?php
                if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                    <?php
                }

                if ( wbg_fs()->is_plan__premium_only('pro') ) {
                    ?>
                    <input type="number" class="small-text" min="0" max="10" name="wbg_single_modal_border_width" id="wbg_single_modal_border_width" value="<?php esc_attr_e( $wbg_single_modal_border_width ); ?>">
                    <code>px</code>
                    <?php
                }
                ?>
            </td>
        </tr>
    </table>
    <hr>
    <p class="submit">
        <button id="updateSingleStyles" name="updateSingleStyles" class="button button-primary wbg-button">
            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<?php _e('Save Settings', WBG_TXT_DOMAIN); ?>
        </button>
    </p>
</form>