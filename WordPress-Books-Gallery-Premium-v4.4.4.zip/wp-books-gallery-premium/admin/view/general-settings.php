<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

//print_r( $wbgCoreSettings );
foreach ( $wbgCoreSettings as $option_name => $option_value ) {
    if ( isset( $wbgCoreSettings[$option_name] ) ) {
        ${"" . $option_name}  = $option_value;
    }
}
/*
$roles = get_editable_roles();
foreach ( $roles as $role_id => $role_data ) {
    echo '<br>' . $role_data['name'];
}
*/
?>
<div id="wph-wrap-all" class="wrap wbg-settings-page">

    <div class="settings-banner">
        <h2><i class="fa fa-cogs" aria-hidden="true"></i>&nbsp;<?php _e('General Settings', WBG_TXT_DOMAIN); ?></h2>
    </div>

    <?php 
    if ( $wbgShowCoreMessage ) { 
        $this->wbg_display_notification('success', 'Your information updated successfully.'); 
    } 
    ?>
    <br>
    <div class="wbg-wrap">

        <div class="wbg_personal_wrap wbg_personal_help" style="width: 75%; float: left;">
        
            <form name="wbg_general_settings_form" role="form" class="form-horizontal" method="post" action="" id="wbg-general-settings-form">
            <table class="wbg-general-settings-table">
                <tr>
                    <th scope="row">
                        <label><?php _e('Gallery Page Slug', WBG_TXT_DOMAIN); ?></label>
                    </th>
                    <td colspan="3">
                        <input type="text" name="wbg_gallery_page_slug" class="medium-text" value="<?php esc_attr_e( $wbg_gallery_page_slug ); ?>">
                        <?php _e('This is your Gallery Page URL slug.', WBG_TXT_DOMAIN); ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label><?php _e('Prefered Author', WBG_TXT_DOMAIN); ?></label>
                    </th>
                    <td colspan="3">
                        <?php
                        if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                            ?>
                            <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                            <?php
                        }

                        if ( wbg_fs()->is_plan__premium_only('pro') ) {
                            ?>
                            <input type="radio" name="wbg_prefered_author" id="wbg_prefered_author_single" value="single" <?php echo ( 'single' === $wbg_prefered_author ) ? 'checked' : ''; ?> >
                            <label for="wbg_prefered_author_single"><span></span><?php _e( 'Single', WBG_TXT_DOMAIN ); ?></label>
                            &nbsp;&nbsp;
                            <input type="radio" name="wbg_prefered_author" id="wbg_prefered_author_multy" value="multy" <?php echo ( 'single' !== $wbg_prefered_author ) ? 'checked' : ''; ?> >
                            <label for="wbg_prefered_author_multy"><span></span><?php _e( 'Multiple', WBG_TXT_DOMAIN ); ?></label>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="wbg_download_when_logged_in"><?php _e('Download When Logged-in', WBG_TXT_DOMAIN); ?>?</label>
                    </th>
                    <td colspan="3">
                        <?php
                        if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                            ?>
                            <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                            <?php
                        }

                        if ( wbg_fs()->is_plan__premium_only('pro') ) {
                            ?>
                            <input type="checkbox" name="wbg_download_when_logged_in" class="wbg_download_when_logged_in" id="wbg_download_when_logged_in" value="1"
                                <?php echo $wbg_download_when_logged_in ? 'checked' : ''; ?> >
                            <?php _e('With enabled, only logged-in users can download books.', WBG_TXT_DOMAIN); ?>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label><?php _e('Affiliate Code', WBG_TXT_DOMAIN); ?></label>
                    </th>
                    <td>
                        <?php
                        if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                            ?>
                            <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                            <?php
                        }

                        if ( wbg_fs()->is_plan__premium_only('pro') ) {
                            ?>
                            <input type="text" name="wbg_affiliate_code" class="medium-text" value="<?php esc_attr_e( $wbg_affiliate_code ); ?>">
                            <?php
                        }
                        ?>
                    </td>
                    <th scope="row">
                        <label><?php _e('Code Apply To URL', WBG_TXT_DOMAIN); ?></label>
                    </th>
                    <td>
                        <?php
                        if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                            ?>
                            <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                            <?php
                        }

                        if ( wbg_fs()->is_plan__premium_only('pro') ) {
                            ?>
                            <input type="radio" name="wbg_affiliate_code_apply" id="wbg_affiliate_code_apply_download" value="download" <?php echo ( 'download' === $wbg_affiliate_code_apply ) ? 'checked' : ''; ?> >
                            <label for="wbg_affiliate_code_apply_download"><span></span><?php _e('Downloand', WBG_TXT_DOMAIN); ?></label>
                            &nbsp;&nbsp;
                            <input type="radio" name="wbg_affiliate_code_apply" id="wbg_affiliate_code_apply_buy" value="buy" <?php echo ( 'download' !== $wbg_affiliate_code_apply ) ? 'checked' : ''; ?> >
                            <label for="wbg_affiliate_code_apply_buy"><span></span><?php _e('Buy', WBG_TXT_DOMAIN); ?></label>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label><?php _e('Book Cover Priority', WBG_TXT_DOMAIN); ?></label>
                    </th>
                    <td colspan="3">
                        <?php
                        if ( ! wbg_fs()->is_plan__premium_only('pro') ) {
                            ?>
                            <span><?php echo '<a href="' . wbg_fs()->get_upgrade_url() . '">' . __('Upgrade to Professional!', WBG_TXT_DOMAIN) . '</a>'; ?></span>
                            <?php
                        }

                        if ( wbg_fs()->is_plan__premium_only('pro') ) {
                            ?>
                            <input type="radio" name="wbg_book_cover_priority" id="wbg_book_cover_priority_f" value="f" <?php echo ( 'f' === $wbg_book_cover_priority ) ? 'checked' : ''; ?> >
                            <label for="wbg_book_cover_priority_f"><span></span><?php _e( 'Default', WBG_TXT_DOMAIN ); ?></label>
                            &nbsp;&nbsp;
                            <input type="radio" name="wbg_book_cover_priority" id="wbg_book_cover_priority_i" value="i" <?php echo ( 'f' !== $wbg_book_cover_priority ) ? 'checked' : ''; ?> >
                            <label for="wbg_book_cover_priority_i"><span></span><?php _e( 'Imported', WBG_TXT_DOMAIN ); ?></label>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
            </table>
            <hr>
            <p class="submit">
                <button id="updateCoreSettings" name="updateCoreSettings"
                    class="button button-primary wbg-button"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<?php _e('Save Settings', WBG_TXT_DOMAIN); ?>
                </button>
            </p>
            </form>

        </div>

        <?php include_once('partial/admin-sidebar.php'); ?> 

    </div>

</div>