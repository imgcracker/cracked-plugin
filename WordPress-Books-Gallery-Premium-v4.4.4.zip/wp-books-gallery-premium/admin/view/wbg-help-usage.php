<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wbg-wrap" style="padding-top:20px;">
    <div class="wbg_personal_wrap wbg_personal_help" style="width: 72%; float: left; text-align: center;">
        <h1>WordPress Books Gallery Video Tutorial</h1>
        <div class="help-link">
            <iframe width="800" height="450" src="https://www.youtube.com/embed/cSZ5cve2Uuw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    </div>
    
    <?php include_once('partial/admin-sidebar.php'); ?>
    
</div>