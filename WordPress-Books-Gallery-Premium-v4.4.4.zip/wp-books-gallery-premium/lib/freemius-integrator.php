<?php

if ( !defined( 'ABSPATH' ) ) {
    exit;
}

if ( !function_exists( 'wbg_fs' ) ) {
    // Create a helper function for easy SDK access.
    function wbg_fs()
    {
        global  $wbg_fs ;
		
        if ( !isset( $wbg_fs ) ) {
			class wbgFsNull {
				public function is_plan__premium_only() {
					return 'pro';
				}
				public function get_upgrade_url() {
					return '';
				}
				public function add_filter( $tag, $function_to_add, $priority = 10, $accepted_args = 1 ) {
					add_filter( $tag, $function_to_add, $priority, $accepted_args );
				}
				public function add_action( $tag, $function_to_add, $priority = 10, $accepted_args = 1 ) {
					add_action( $tag, $function_to_add, $priority, $accepted_args );
				}
			}
            // Include Freemius SDK.
            require_once WBG_PATH . '/freemius/start.php';
            $wbg_fs = new wbgFsNull();
        }
        
        return $wbg_fs;
    }
    
    // Init Freemius.
    wbg_fs();
    // Signal that SDK was initiated.
    do_action( 'wbg_fs_loaded' );
    function wbg_fs_support_forum_url( $wp_support_url )
    {
        return 'https://wordpress.org/support/plugin/wp-books-gallery/';
    }
    
    wbg_fs()->add_filter( 'support_forum_url', 'wbg_fs_support_forum_url' );
    function wbg_fs_custom_connect_message_on_update(
        $message,
        $user_first_name,
        $plugin_title,
        $user_login,
        $site_link,
        $freemius_link
    )
    {
        return sprintf(
            __( 'Hey %1$s' ) . ',<br>' . __( 'Please help us improve %2$s! If you opt-in, some data about your usage of %2$s will be sent to %5$s. If you skip this, that\'s okay! %2$s will still work just fine.', WBG_TXT_DOMAIN ),
            $user_first_name,
            '<b>' . $plugin_title . '</b>',
            '<b>' . $user_login . '</b>',
            $site_link,
            $freemius_link
        );
    }
    
    wbg_fs()->add_filter(
        'connect_message_on_update',
        'wbg_fs_custom_connect_message_on_update',
        10,
        6
    );
    function wbg_fs_uninstall_cleanup()
    {
        global  $wpdb ;
        $tbl = $wpdb->prefix . 'options';
        $search_string = 'wbg_%';
        $sql = $wpdb->prepare( "SELECT option_name FROM {$tbl} WHERE option_name LIKE %s", $search_string );
        $options = $wpdb->get_results( $sql, OBJECT );
        if ( is_array( $options ) && count( $options ) ) {
            foreach ( $options as $option ) {
                delete_option( $option->option_name );
                delete_site_option( $option->option_name );
            }
        }
    }
    
    wbg_fs()->add_action( 'after_uninstall', 'wbg_fs_uninstall_cleanup' );
}
