<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Subtitle
if ( wbg_fs()->is_plan__premium_only('pro') ) {

    if ( $wbg_display_subtitle ) {

        if ( '' !== $wbg_sub_title ) {
            echo '<div class="wbg-single-subtitle">- ' . esc_html( $wbg_sub_title ) . '</div>';
        }

    }

    if ( $wbg_display_rating ) {
        echo $wbg_front_new->wbg_load_rating( $post->ID );
    }
} 

if ( wbg_fs()->is_plan__premium_only('basic') ) {
    ?>
    <div class="regular-price">
        <?php
        $wbgp_regular_price  = get_post_meta( $post->ID, 'wbgp_regular_price', true );
        $wbgp_sale_price     = get_post_meta( $post->ID, 'wbgp_sale_price', true );
        if ( empty( $wbgp_sale_price ) ) {
            echo ( ! empty( $wbgp_regular_price ) ) ? '<span class="wbgp-price price-after">' . esc_html( $wbgpCurrencySymbol ) . number_format( ( esc_html( $wbgp_regular_price ) / 100 ), 2, ".", "" ) . '</span>' : '';
        } else {
            echo '<span class="wbgp-price price-before">' . esc_html( $wbgpCurrencySymbol ) . number_format( ( esc_html( $wbgp_regular_price ) / 100 ), 2, ".", "" ) . '</span>&nbsp;&nbsp;<span class="wbgp-price price-after">' . esc_html( $wbgpCurrencySymbol ) . number_format( ( esc_html( $wbgp_sale_price ) / 100 ), 2, ".", "" ) . '</span>';
        }
        ?>
    </div>
    <?php
    // Format
    if ( ! empty( $wbgFormat ) ) {
        if ( $wbg_display_format ) {
            ?>
            <span>
                <b><i class="fa fa-object-ungroup" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_format_label ); ?>:</b>
                <?php
                $wbgFormatArray = array();
                foreach( $wbgFormat as $format ) {
                    $wbgFormatArray[] = $format->name . '';
                }
                echo implode( ', ', $wbgFormatArray );
                ?>
            </span>
            <?php
        }
    }

    // Series
    if ( ! empty( $wbgSeries ) ) {
        if ( $wbg_display_series ) {
            ?>
            <span>
                <b><i class="fa fa-reorder" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_series_label ); ?>:</b>
                <?php
                $wbgSeriesArray = array();
                foreach( $wbgSeries as $series) {
                    $wbgSeriesArray[] = $series->name . '';
                }
                echo implode( ', ', $wbgSeriesArray );
                ?>
            </span>
            <?php
        }
    }
}

// Author
if ( $wbg_author_info ) {
    if ( ! empty( $wbgAuthor ) ) {
        ?>
        <span>
            <b><i class="fa fa-user-circle" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_author_label ); ?>:</b>
            <a href="<?php echo esc_url( home_url( '/' . $wbg_gallery_page_slug . '/?wbg_author_s=' . urlencode( $wbgAuthor )  ) ); ?>" class="wbg-single-link">
                <?php esc_html_e( $wbgAuthor ); ?>
            </a>
            <?php
            if ( wbg_fs()->is_plan__premium_only('pro') ) {
                if ( 'multy' === $wbg_prefered_author ) {
                $wbgAuthorArray = array();
                $wbgAuthors = wp_get_post_terms( $post->ID, 'book_author', array('fields' => 'all') );
                foreach( $wbgAuthors as $authorVal ) {
                    $wbgAuthorArray[] = $authorVal->name . '';
                }
                echo ', ' . implode( ', ', $wbgAuthorArray );
                }
            }
            ?>
        </span>
        <?php 
    }
}

// Category
if ( $wbg_display_category ) { 
    ?>
    <span>
        <b><i class="fa fa-list-ul" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_category_label ); ?>:</b>
        <?php
        $wbgCatArray = array();
        foreach( $wbgCategory as $cat) {
            $wbgCatArray[] = "<a href='" . esc_url( home_url( '/' . $wbg_gallery_page_slug . '/?wbg_category_s=' . urlencode( $cat->name )  ) ) . "' class='wbg-single-link'>" . $cat->name . "</a>";
        }
        echo implode( ', ', $wbgCatArray );
        ?>
    </span>
    <?php 
}

// Reading Age
if ( wbg_fs()->is_plan__premium_only('pro') ) {
    
    if ( ! empty( $reading_ages ) ) {
        if ( $wbg_display_reading_age ) {
            ?>
            <span>
                <b><i class="fa fa-meh-o" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_reading_age_label ); ?>:</b>
                <?php
                $reading_ages_arr = array();
                foreach( $reading_ages as $reading_age) {
                    $reading_ages_arr[] = $reading_age->name . '';
                }
                echo implode( ', ', $reading_ages_arr );
                ?>
            </span>
            <?php
        }
    }
}

// Grade level
if ( wbg_fs()->is_plan__premium_only('pro') ) {
    
    if ( ! empty( $grade_levels ) ) {
        if ( $wbg_display_grade_level ) {
            ?>
            <span>
                <b><i class="fa fa-graduation-cap" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_grade_level_label ); ?>:</b>
                <?php
                $grade_level_arr = array();
                foreach( $grade_levels as $grade_level) {
                    $grade_level_arr[] = $grade_level->name . '';
                }
                echo implode( ', ', $grade_level_arr );
                ?>
            </span>
            <?php
        }
    }
}

// Publisher
if ( $wbg_display_publisher ) {
    if ( ! empty( $wbgPublisher ) ) {
        ?>
        <span>
            <b><i class="fa fa-building" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_publisher_label ); ?>:</b>
            <?php esc_html_e( $wbgPublisher ); ?>
        </span>
        <?php
    }
}

// Co-Publishers
if ( wbg_fs()->is_plan__premium_only('pro') ) {
    if ( $wbg_display_co_publisher ) {
        if ( ! empty( $wbg_co_publisher ) ) {
            ?>
            <span>
                <b><i class="fa fa-building" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_co_publisher_label ); ?>:</b>
                <?php esc_html_e( $wbg_co_publisher ); ?>
            </span>
            <?php
        }
    }
}

// Publish Date
if ( $wbg_display_publish_date ) {
    if ( ! empty( $wbgPublished ) ) {
        ?>
        <span>
            <b><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_publish_date_label ); ?>:</b>
            <?php
                if ( 'full' === $wbg_publish_date_format ) {
                    echo date('d M, Y', strtotime( $wbgPublished ) );
                } else {
                    echo date('Y', strtotime( $wbgPublished ) );
                }
            ?>
        </span>
    <?php
    }
} 

// ISBN
if ( $wbg_display_isbn ) {
    if ( ! empty( $wbgIsbn ) ) {
        ?>
        <span>
            <b><i class="fa fa-barcode" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_isbn_label ); ?>:</b>
            <?php esc_html_e( $wbgIsbn ); ?>
        </span>
        <?php
    }
}

// ISBN-13
if ( wbg_fs()->is_plan__premium_only('pro') ) {
    if ( $wbg_display_isbn_13 ) {
        if ( ! empty( $wbg_isbn_13 ) ) {
            ?>
            <span>
                <b><i class="fa fa-barcode" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_isbn_13_label ); ?>:</b>
                <?php esc_html_e( $wbg_isbn_13 ); ?>
            </span>
            <?php
        }
    }
}

// ASIN
if ( wbg_fs()->is_plan__premium_only('pro') ) {
    //if ( $wbg_display_isbn_13 ) {
        if ( ! empty( $wbg_asin ) ) {
            ?>
            <span>
                <b><i class="fa fa-barcode" aria-hidden="true"></i>&nbsp;<?php _e('ASIN', WBG_TXT_DOMAIN); ?>:</b>
                <?php esc_html_e( $wbg_asin ); ?>
            </span>
            <?php
        }
    //}
}

// Pages
if ( $wbg_display_page ) {
    if ( ! empty( $wbgPages ) ) {
    ?>
    <span>
        <b><i class="fa fa-file-text" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_page_label ); ?>:</b>
        <?php esc_html_e( $wbgPages ); ?>
    </span>
    <?php
    }
} 

if ( $wbg_display_country ) {
    if ( ! empty( $wbgCountry ) ) {
    ?>
    <span>
        <b><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_country_label ); ?>:</b>
        <?php esc_html_e( $wbgCountry ); ?>
    </span>
    <?php
    }
} 

if ( $wbg_display_language ) { 
    if ( ! empty( $wbgLanguage ) ) {
        ?>
        <span>
            <b><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_language_label ); ?>:</b>
            <?php esc_html_e( $wbgLanguage ); ?>
        </span>
        <?php 
    }
} 

if ( $wbg_display_dimension ) { 
    if ( ! empty( $wbgDimension ) ) {
        ?>
        <span>
            <b><i class="fa fa-arrows" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_dimension_label ); ?>:</b>
            <?php esc_html_e( $wbgDimension ); ?>
        </span>
        <?php
    }
} 

// Filesize
if ( $wbg_display_filesize ) {
    
    if ( ! empty( $wbgFilesize ) ) {
        ?>
        <span>
            <b><i class="fa fa-file" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_filesize_label ); ?>:</b>
            <?php esc_html_e( $wbgFilesize ); ?>
        </span>
        <?php
    }

}

// Weight
if ( wbg_fs()->is_plan__premium_only('pro') ) {

    if ( $wbg_display_item_weight ) {

        if ( ! empty( $wbg_item_weight ) ) {
            ?>
            <span>
                <b><i class="fa fa-balance-scale" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_item_weight_label ); ?>:</b>
                <?php esc_html_e( $wbg_item_weight ); ?>
            </span>
            <?php
        }

    }

}

// Edition
if ( wbg_fs()->is_plan__premium_only('pro') ) {

    if ( $wbg_display_edition ) {

        if ( ! empty( $wbg_edition ) ) {
            ?>
            <span>
                <b><i class="fa fa-book" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_edition_label ); ?>:</b>
                <?php esc_html_e( $wbg_edition ); ?>
            </span>
            <?php
        }

    }

}

// Illustrator
if ( wbg_fs()->is_plan__premium_only('pro') ) {

    if ( $wbg_display_illustrator ) {

        if ( ! empty( $wbg_illustrator ) ) {
            ?>
            <span>
                <b><i class="fa fa-paint-brush" aria-hidden="true"></i>&nbsp;<?php esc_html_e( $wbg_illustrator_label ); ?>:</b>
                <?php esc_html_e( $wbg_illustrator ); ?>
            </span>
            <?php
        }
    }
}

do_action( 'wbg_front_single_load_custom_fields_data' ); 
?>