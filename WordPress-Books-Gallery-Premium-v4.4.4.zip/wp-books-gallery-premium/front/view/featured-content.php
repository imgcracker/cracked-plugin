<?php
# Silence is golden.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( wbg_fs()->is_plan__premium_only('pro') ) {
   
    while( $wbgBooks->have_posts() ) {

        $wbgBooks->the_post();
        $wbgCategory    = wp_get_post_terms( $post->ID, 'book_category', array('fields' => 'all') );
        $wbgImgUrl      = get_post_meta( $post->ID, 'wbgp_img_url', true );
        $wbgAuthor      = get_post_meta( $post->ID, 'wbg_author', true );
        ?>
        <div class="wbg-item">
            <a class="wgb-item-link" href="<?php echo esc_url( get_the_permalink( $post->ID ) ); ?>">
                <?php
                if ( $wbgImgUrl ) {
                    ?>
                    <img class="wbg-featured-img" src="<?php echo esc_url( $wbgImgUrl ); ?>" alt="<?php _e( 'No Image Available', WBG_TXT_DOMAIN ); ?>" width="200">
                    <?php
                }
                else if ( has_post_thumbnail() ) {
                    //the_post_thumbnail( array( 200 ) );
                    $feat_image = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
                    ?>
                    <img class="wbg-featured-img" src="<?php echo esc_url( $feat_image ); ?>" alt="<?php _e( 'No Image Available', WBG_TXT_DOMAIN ); ?>" width="200">
                    <?php
                } else { ?>
                    <img class="wbg-featured-img" src="<?php esc_attr_e( WBG_ASSETS . 'img/noimage.jpg' ); ?>" alt="<?php _e( 'No Image Available', WBG_TXT_DOMAIN ); ?>" width="200">
                <?php
                }
                ?>
                <?php echo get_the_title(); ?>
            </a>
            <span>
                <?php
                $wbgCatArray = array();
                foreach( $wbgCategory as $cat) {
                    $wbgCatArray[] = $cat->name . '';
                }
                echo implode( ', ', $wbgCatArray );
                ?>
            </span>
            <?php
            if (  ! empty( $wbgAuthor ) ) {
                ?>
                <span><?php esc_html_e( $wbgAuthor ); ?></span>
                <?php
            }

            if ( 'on' == $wbg_rating ) {
                echo $this->wbg_load_rating( $post->ID );
            }
            ?>
            <div class="wbg-button-container">
                <?php 
                if ( 'on' == $wbg_download_btn ) { 
                    $wbgLink = get_post_meta( $post->ID, 'wbg_download_link', true );
                    if ( $wbgLink !== '' ) {
                        
                        if ( wbg_fs()->is_plan__premium_only('pro') ) {
                        $wbgLink = ( '' !== $wbg_affiliate_code ) && ( 'download' === $wbg_affiliate_code_apply ) ? $wbgLink . $wbg_affiliate_code : $wbgLink;
                        }

                        if ( $wbg_buynow_btn_txt !== '' ) {
                            if ( $wbg_download_when_logged_in ) {
                                if ( is_user_logged_in() ) {
                                    ?>
                                    <a href="<?php echo esc_url( $wbgLink ); ?>" class="button wbg-btn" target="_blank">
                                        <i class="fa-solid fa-download"></i>&nbsp;<?php esc_html_e( $wbg_buynow_btn_txt ); ?>
                                    </a>
                                    <?php
                                }
                            }
                            if ( ! $wbg_download_when_logged_in ) {
                                ?>
                                <a href="<?php echo esc_url( $wbgLink ); ?>" class="button wbg-btn" target="_blank">
                                <i class="fa-solid fa-download"></i>&nbsp;<?php esc_html_e( $wbg_buynow_btn_txt ); ?>
                                </a>
                                <?php
                            }
                        }
                    }
                } 
                
                $wbgp_buy_link = get_post_meta( $post->ID, 'wbgp_buy_link', true );
                
                if ( 'on' == $wbg_buy_btn ) {

                    if ( $wbgp_buy_link !== '' ) {
                        $wbgp_buy_link = ( '' !== $wbg_affiliate_code ) && ( 'buy' === $wbg_affiliate_code_apply ) ? $wbgp_buy_link . $wbg_affiliate_code : $wbgp_buy_link;
                        ?>
                        <a href="<?php echo esc_url( $wbgp_buy_link ); ?>" class="button wbg-btn" target="_blank">
                            <i class="fa-solid fa-cart-shopping"></i>&nbsp;<?php esc_html_e( $wbg_buy_now_btn_txt ); ?>
                        </a>
                        <?php
                    }

                }
                ?>
            </div>
        </div>
        <?php 
    }
}
?>