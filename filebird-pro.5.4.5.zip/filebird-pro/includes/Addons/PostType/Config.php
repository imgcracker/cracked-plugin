<?php
return array(
    'taxonomy_prefix'       => 'fbv_pt_tax_',
    'order_meta_key'        => 'fbv_tax_order',
    'saved_sort_folder_key' => 'njt_fb_sort_folder_pt',
    'author_key'            => 'fbv_author',
);
